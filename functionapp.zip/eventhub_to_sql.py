# Register this blueprint by adding the following line of code 
# to your entry point file.  
# app.register_functions(save_to_sql) 
# 
# Please refer to https://aka.ms/azure-functions-python-blueprints

import logging
import azure.functions as func


sql_blueprint = func.Blueprint()


@sql_blueprint.event_hub_message_trigger(arg_name="azeventhub", event_hub_name="weatherstreamingeventhub",
                               connection="AzureEventHubConnection") 

def save_to_sql(azeventhub: func.EventHubEvent):
    logging.info('Python EventHub trigger processed an event: %s',
                azeventhub.get_body().decode('utf-8'))
